<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect("localhost","root","","data") or die ("could not connect database");
?>